module.exports = (hexo) => {
    hexo.log.info(`
=============================================
Welcome from Anatolo!
=============================================`);
}